# Language Learning Platform

A React + TypeScript application for learning programming languages through interactive games and quizzes.

## Features

- User authentication with username/password
- Theme selection (light/dark mode)
- Multiple programming languages (Python, JavaScript, C, Java, C++, Ruby)
- Interactive coding games
- Multiple-choice quizzes
- Progress tracking
- Admin panel for content management

## Tech Stack

- React 18 + TypeScript
- Vite
- Tailwind CSS
- shadcn/ui components
- Supabase (backend + auth)
- Framer Motion (animations)

## Setup

1. Install dependencies:
```bash
npm install
```

2. Create `.env` file with your Supabase credentials:
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

3. Run development server:
```bash
npm run dev
```

## Admin Account

Username: turki algamdi
Password: turkialso

## Project Structure

- `/src/pages` - All application pages
- `/src/components` - Reusable components
- `/src/contexts` - React contexts (Auth)
- `/src/types` - TypeScript type definitions
- `/supabase` - Database migrations and Edge Functions

Made by turki
