import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
// ... other imports

export const routes = [
  { name: 'Login', path: '/login', element: <LoginPage />, public: true },
  { name: 'Dashboard', path: '/', element: <DashboardPage /> },
  // ... other routes
];