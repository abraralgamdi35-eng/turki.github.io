import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
// ... full DashboardPage implementation with animations