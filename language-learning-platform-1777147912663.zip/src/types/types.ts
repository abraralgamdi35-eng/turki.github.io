export type UserRole = 'user' | 'admin';
export type Theme = 'light' | 'dark';

export interface Profile {
  id: string;
  email: string | null;
  role: UserRole;
  interface_language: string;
  theme: Theme;
  created_at: string;
  updated_at: string;
}

// ... other types